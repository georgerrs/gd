import React from 'react';
import Layout from '../../components/Layout';
import howWeWork from './howWeWork';

const title = 'How We Work';

export default {

  path: '/how-we-work',

  action() {
    return {
      title,
      component: <Layout><How We Work title={title} /></Layout>,
    };
  },

};
